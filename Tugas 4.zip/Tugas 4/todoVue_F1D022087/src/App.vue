<script setup>
import { ref } from 'vue';

const tasks = ref([]);
const newTask = ref('');

const addTask = () => {
  if (newTask.value.trim() !== '') {
    tasks.value.push(newTask.value);
    newTask.value = '';
  }
};

const deleteTask = (index) => {
  tasks.value.splice(index, 1);
};
</script>

<template>
  <div class="container">
    <h1>Todo List Vue</h1>

    <form @submit.prevent="addTask" class="input-group">
      <input 
        v-model="newTask" 
        placeholder="Masukkan tugas baru..." 
        required
      />
      <button type="submit">Tambah</button>
    </form>

    <ul v-if="tasks.length > 0">
      <li v-for="(task, index) in tasks" :key="index">
        <span>{{ task }}</span>
        <button @click="deleteTask(index)" class="delete-btn">Hapus</button>
      </li>
    </ul>

    <p v-else class="empty-msg">Tidak ada tugas</p>
  </div>
</template>

<style scoped>
.container {
  max-width: 400px;
  margin: 50px auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-family: sans-serif;
  box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
}

h1 {
  text-align: center;
  color: #2c3e50;
}

.input-group {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

input {
  flex: 1;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 8px 12px;
  background-color: #42b883;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #3aa876;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  background: #f9f9f9;
  margin: 5px 0;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 4px;
}

.delete-btn {
  background-color: #ff4d4d;
  font-size: 0.8em;
}

.delete-btn:hover {
  background-color: #d93636;
}

.empty-msg {
  text-align: center;
  color: #888;
  font-style: italic;
}
</style>